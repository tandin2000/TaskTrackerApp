package com.example.finalmadproject.TanPart;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import com.example.finalmadproject.R;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    }
}