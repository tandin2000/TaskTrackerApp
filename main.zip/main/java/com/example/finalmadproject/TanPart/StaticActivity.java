package com.example.finalmadproject.TanPart;

import android.os.Bundle;
import com.example.finalmadproject.R;
import androidx.appcompat.app.AppCompatActivity;

public class StaticActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_static);
    }
}