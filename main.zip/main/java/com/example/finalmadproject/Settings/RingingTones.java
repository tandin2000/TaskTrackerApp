package com.example.finalmadproject.Settings;

public final class RingingTones {
    public static class song{
        public static final String TABLE_SONG_NAME = "song";
        public static final String SONG_ID = "song_id";
        public static final String SONG_NAME = "song_name";
        //added
        public static final String SONG_STATUS = "song_status";
        public static final String SONG_PATH = "song_path";
    }
}
