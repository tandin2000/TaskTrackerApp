package com.example.finalmadproject.Settings;

public final class Notification {
    public static class notification{
        public static final String TABLE_NOTIFICATION_NAME = "notification";
        public static final String NOTIFICATION_ID = "notification_id";
        public static final String NOTIFICATION = "notification";
    }
}
